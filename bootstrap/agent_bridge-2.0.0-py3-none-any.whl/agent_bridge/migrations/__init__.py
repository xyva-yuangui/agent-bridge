"""Versioned SQLite schema resources."""
